from django.db import models

# Create your models here.
class SensorData(models.Model):
    id = models.AutoField(primary_key=True)
    date = models.DateField(max_length=15)
    time = models.TimeField(max_length=15)
    light = models.FloatField(max_length=15)
    nitrogen_data = models.SmallIntegerField()
    phosphorus_data = models.SmallIntegerField()
    potassium_data = models.SmallIntegerField()
    relative_humidity = models.FloatField(max_length = 5)
    temp_c = models.FloatField(max_length = 5)
    temp_f = models.FloatField(max_length = 5)
    soil_moisture = models.FloatField(max_length = 5)


class DailyAvg(models.Model):
    date = models.DateField(max_length=15)
    light_avg = models.FloatField(max_length=15)
    nitrogen_data_avg = models.SmallIntegerField()
    phosphorus_data_avg = models.SmallIntegerField()
    potassium_data_avg = models.SmallIntegerField()
    relative_humidity_avg = models.FloatField(max_length = 5)
    temp_c_avg = models.FloatField(max_length = 5)
    temp_f_avg = models.FloatField(max_length = 5)
    soil_moisture_avg = models.FloatField(max_length = 5)


